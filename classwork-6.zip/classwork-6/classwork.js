// do while
let count = 1;
do {
    console.log("Count:", count);
    count++;
} while (count <= 5);
//for loop
for(let i=0;i<10;i++)
{
    let name="laiba gull"
    console.log(name[i]);
}
let bookInfo =

 {
     bookName:"alchemy of souls",
     price:289,
     copies:100,
     color:"yellow",

 };
 for( let key in bookInfo){
     console.log(key,bookInfo[key]);

    
 }

//for of loop
let arrayNumber=[2,3,4,56,];
for(let key of arrayNumber)
    {
        let answer= key*2;
        console.log(answer)
}
//type of array
let arrName=["rani","Muqadas","laiba",]
console.log(typeof(arrName));
//for of
let marks=[34,56,76,54,34]
let sum=0;
for(let value of marks)
{
    sum+=value;
}
let avg=sum/marks.length;
console.log("average is:",avg);
//array
let fruits=["apple","grapes","bananas"];
let marks2=[43,65,3,54,23];
console.log(fruits);
console.log(fruits.toString());
console.log(fruits);
//array concatenate 
let students=["zainab","Ayesha"];
let friends=["Sumiya","Ammara"];
let combine1=students.concat(friends);
console.log(combine1);
//slice and spice
let arrNum=[2,5,64,87,34,67,32,67,87,42];
console.log(arrNum);
let arrNumsl=arrNum.slice(3,6);
console.log(arrNumsl);
let arrNumsp1=arrNum.splice(3,6);
let arrNumsp2=arrNum.splice(34,67);
//push and pop from array
 let arrSeason=["Spring","summer","Autumn"];
 console.log(arrSeason);
let completeSeason=arrSeason.push("winter");
console.log(completeSeason);
let deleteSeason=arrSeason.pop();
console.log(deleteSeason);
//Function to print a name
function greet(name) {
    return "Hello, " + name;
}
console.log(greet("Gul"));
//local variable
function solution(x,y){
    t=x+y;
    return t;
    console.log(x);
    
}
let val=solution(4,5);
console.log(val);
solution(4,5);
//for each function
let arrplus = [12, 5, 4, 3, 7, 89, 4];
arrplus.forEach(function(number) {
    let c = number * 3;
    console.log(c);
});
//map function
let numbersArray = [12, 5, 4, 3, 7, 89, 4];
let tripledValues = numbersArray.map(function(number) {
    return number * 6;
});

console.log(tripledValues);
//filter funtion
let numbersArray3 = [12, 5, 4, 3, 7, 89, 4];
let filteredValues = numbersArray3.filter(function(number) {
    return number > 10;
});

console.log(filteredValues);
//reduced function
let numbersArray5 = [12, 5, 4, 3, 7, 89, 4];
let totalSum = numbersArray5.reduce((acc, num) => acc + num, 0);

console.log(totalSum);
