
function getGrade(score) {
    if (score >= 80 && score <= 100) {
        return 'A';
    } else if (score >= 70 && score < 80) {
        return 'B';
    } else if (score >= 60 && score < 70) {
        return 'C';
    } else if (score >= 50 && score < 60) {
        return 'D';
    } else if (score >= 0 && score < 50) {
        return 'F';
    } else {
        return 'Invalid score';
    }
}


const userInput = prompt("Enter the student's score (0-100):");
const score = Number(userInput);


const grade = getGrade(score);

console.log("The grade for a score of", score,grade);