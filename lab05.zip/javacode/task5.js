
const userInput = prompt("Enter a number:");


const number = Number(userInput);


if (number % 3 === 0) {
    console.log( " a multiple of 3:",number);
} else {
    console.log(" not a multiple of 3:",number);
}