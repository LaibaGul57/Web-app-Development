const instagramProfile = {
    username: "aliyan_margret",
    fullName: "Aliyan Margret",
    bio: "Power corrupts,and absolute power corrupts absolutely",
    followers: 7,
    following: 42,
    profilePicture: "inst.jpg",
}
function displayProfileInfo() {
    console.log(instagramProfile.username);
    console.log(instagramProfile.fullName);
    console.log(instagramProfile.bio);
    console.log(instagramProfile.followers);
    console.log(instagramProfile.following);
    console.log(instagramProfile.profilePicture);
    }
displayProfileInfo();
