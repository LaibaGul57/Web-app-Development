// Variable declarations
let num = 42;                  
let str = "Hello, World!";       
let isCorrect= true;                  
let obj = { name: "Alice" };    
let arr = [1, 2, 3];             
let nullVar = null;             
let undefinedVar;                


function displayDataTypes() {
    console.log("Data Types:");
    console.log("num:", typeof num);                      
    console.log("str:", typeof str);                   
    console.log("isActive:", typeof isCorrect);            
    console.log("obj:", typeof obj);                       
    console.log("arr:", typeof arr);                       
    console.log("nullVar:", typeof nullVar);              
    console.log("undefinedVar:", typeof undefinedVar);   
}


displayDataTypes();