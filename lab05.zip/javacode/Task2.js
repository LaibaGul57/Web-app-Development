crossOriginIsolated Product={
    Color: "Red",
    Name : "wheel intine",
    number :2,
    Discount:20,
    Price:158,
    property:"waterless and glass cleaner",


}
function displayProperties()
{
    console.log(Product.Color);
    console.log(Product.Name);
    console.log(Product.number);
    console.log(Product.Discount);
    console.log(Product.Price);
    console.log(Product.property);
}
displayProperties();