let a = 7; 

console.log("Initial value of a:", a);


console.log("Using a:", a++); 
console.log("Value of a after a++:", a); 

// ++a
console.log("Using ++a:", ++a); 
console.log("Value of a after ++a:", a); 

//  a--
console.log("Using a--:", a--); 
console.log("Value of a after a--:", a); 

//  --a
console.log("Using --a:", --a); 
console.log("Value of a after --a:", a); 