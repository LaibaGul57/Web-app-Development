// Task 1: Log even numbers from the array
let numbersArray = [12, 5, 4, 3, 7, 89, 4];
let evenNumbers = [];

for (let number of numbersArray) {
    if (number % 2 === 0) {
        console.log("Even Number:", number);
    }
}

// Task 2: Find the largest and smallest numbers in the array
let numArray = [12, 5, 4, 3, 7, 89, 4];
let largest = numArray[0]; 
let smallest = numArray[0];

for (let num of numArray) {
    if (num > largest) {
        largest = num; 
    }
    if (num < smallest) {
        smallest = num; 
    }
}

console.log("Largest value:", largest);
console.log("Smallest value:", smallest);

// Task 3: Convert strings to upper case
function convertStringsToUpperCase(stringsArray) {
    let upperCaseArray = []; 
    for (let str of stringsArray) {
        upperCaseArray.push(str.toUpperCase()); 
    }

    return upperCaseArray;
}

let stringArray = ["hello", "world", "javascript", "is", "fun"];
let resultArray = convertStringsToUpperCase(stringArray);
console.log(resultArray);

// Task 5: Count vowels in a string
function countVowels(str) {
    let count = 0; 
    const vowels = "aeiouAEIOU";
    for (let char of str) {
        if (vowels.includes(char)) { 
            count++; 
        }
    }

    return count; 
}

// Example 
let inputString = "Hello, World!";
let vowelCount = countVowels(inputString);
console.log("Number of vowels:", vowelCount);

// Task 6: Count vowels using arrow function
const countVowelCharacters = (inputString) => {
    let vowelCount = 0; 
    const vowelSet = "aeiouAEIOU"; 
    for (let currentChar of inputString) {
        if (vowelSet.includes(currentChar)) { 
            vowelCount++; 
        }
    }

    return vowelCount; 
};

// Example 
let sampleString = "Hello, World!";
let totalVowels = countVowelCharacters(sampleString);
console.log("Number of vowels:", totalVowels);

// Task 7: Print square of each number in an array
const numbers = [1, 2, 3, 4, 5];
numbers.forEach(num => {
    console.log(num * num); 
});

// Task 8: Filter students with marks greater than 50
const students = [
    { name: 'laiba', marks: 45 },
    { name: 'gul', marks: 65 },
    { name: 'touseef', marks: 30 },
    { name: 'Gullrukh', marks: 85 },
    { name: 'Naina', marks: 55 }
];

// Filter students
const passedStudents = students.filter(student => student.marks > 50);
console.log(passedStudents);

// Task 9: Take input from the user (this requires a browser environment)
const n = 12; 

// Create an array of numbers from 1 to n
const numbers2Array = [];
for (let i = 1; i <= n; i++) {
    numbers2Array.push(i);
}

// Print the array of numbers
console.log(numbers2Array);
// Task 10: Calculate the product of all numbers in an array
const numbers3Array = [1, 2, 3, 4, 5];

const product = numbers3Array.reduce((accumulator, current) => accumulator * current, 1);
console.log("The product of all numbers:", product);