let age = 25;
console.log(age); 

age = 30; 
console.log(age); 


if (false) {
    let insideBlock = "Hello";
    console.log(insideBlock); 
}
//2nd task
let score = 100;
if (score >= 30) {
    console.log("Pass");
} else {
    console.log("Fail");
}
//apply for loop
var sum=9;
for (let i = 0; i < 8; i++) {
    console.log("Iteration: ", sum + i);
}
//3rd task
let pi = 3.1416;  

console.log("Number:", pi); 
let isStudent = true;  
let hasGraduated = false;  
console.log("Boolean:", isStudent); 
console.log("Boolean:", hasGraduated); 

//4th task
var y=true;
var n=false;
if(y==true){
    alert("Got it")
}
if(n==true){
    alert("not getting point")
}
//5th task
const Student={
name:"Gul",
age:22,
SapId:55740,



}
console.log(Student.name)
console.log(Student.age)
Student.age=Student.age +1;
console.log(Student.age)
//6th task
function workCs()
{
    var work= "please complete your task";
     return work;    
}
console.log(workCs());
//workCs();
//7th task

if(6*6==37)
{
    console.log("good calculation")

}
else {
    console.log(",incorrect answer,try again")
}
//8th task
var time= prompt("what's the time" );
if(time>5 &&time<15)
    {
         console.log("Good Morning");
    }
else
     {
        console.log("Good afternoon")
     }
     //task 9th 
    var translation= prompt("please tell me your condition of mood(happy,sad,excited,depressed) then i will give you translation of Ayat");
     switch(translation)
     {
       case 'Happy':
       {
        console.log("If you are grateful, I will give you more(Ibrahim:7)");
       } 
       case 'depressed':
       {
        console.log("But perhaps you hate a thing and it is good for you:and perhaps you love a thing and it is bad for you.And Allah knows,while you don't know (2:216)");
       } 
       case 'sad':
       {
        console.log("Do not despair of the mercy of Allah(39.53)");
       } 
       case 'excited':
       {
        console.log("That it is He who grants laughter and tears(53:43)");
       } 
       default:
       {
        console.log("There is no strength and power except from Allah")
       }
 
     }
//10th task

const fruits = ["Apple", "Banana", "Cherry"];

// Using for...of loop 
console.log("Using for...of loop:");
for (const fruit of fruits) {
    console.log(fruit);
}

// Object for for...in loop
const student = {
    name: "John",
    age: 20,
    major: "Computer Science"
};


console.log("\nUsing for...in loop:");
for (const key in student) {
    console.log(`${key}: ${student[key]}`);
}